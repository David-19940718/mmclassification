# -*- coding: utf-8 -*-
"""
    > File Name: ops.py
    > Author: Magik Development Team
    > Created Time: Fri 03 Jan 2020 11:40:04 AM CST
    > Description:
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import numpy as np
import logging
import warnings
import json

from ingenic_magik_trainingkit.QuantizationTrainingPlugin.python.quantize_ops import *
from ingenic_magik_trainingkit.QuantizationTrainingPlugin.python.lstm_unit import *

index = 1
input_index = 1

__all__ = [
    "Conv2D", "DepthwiseConv2D", "ConvTranspose2D", "FullConnected", "BatchNorm",
    "Flatten", "Route", "Shortcut", "Maxpool2D", "Avgpool2D", "AdaptiveAvgpool2D", "Unpool2D",
    "ReLU6", "ReLU", "Linear", "PReLU", "Hswish", "Hsigmoid",
    "Se_Block", "Mul", "Channel_Split", "Pixel_Shuffle",
    "LSTM", "Embedding", "Focus"
]


class Preprocess(nn.Module):
    def __init__(self, mean=0., var=255., target_device="Txx"):
        super(Preprocess, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        self.mean = mean
        self.var = var
        clip_min_value = 0 if mean == 0 else -1.0
        op_attr = '{"op_type":"Preprocess","attr":{"mean":%f, "var":%f, "output_bitwidth":%d, "clip_min_value":%f}}' % (
            mean, var, 8, clip_min_value)
        self.n_op_out = NOp(op_target="preprocess_end",
                            op_attr=op_attr,
                            target_device=target_device)

    def forward(self, input):
        clip_min_value = 0. if float(self.mean) == 0. else -1.0
        out = input
        if not self.training:
            out = self.n_op_out(out)
        return (out, 8, self.mean, self.var, clip_min_value)


class ReLU6(nn.Module):
    def __init__(self, target_device="Txx"):
        super(ReLU6, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]

    def forward(self, input):
        if isinstance(input, tuple):
            logging.error("ReLU6 can only be used as activation_fn, please check it!")
            exit()
        return nn.ReLU6()(input)


class ReLU(nn.Module):
    def __init__(self, target_device="Txx"):
        super(ReLU, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]

    def forward(self, input):
        if isinstance(input, tuple):
            logging.error("ReLU can only be used as activation_fn, please check it!")
            exit()
        return nn.ReLU()(input)


class Linear(nn.Module):
    def __init__(self, target_device="Txx"):
        super(Linear, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]

    def forward(self, input):
        if isinstance(input, tuple):
            logging.error(
                "Linear can only be used as activation_fn, please check it!")
            exit()
        return input


class BatchNorm(nn.Module):
    def __init__(self,
                 in_channels,
                 activation_fn=Linear(),
                 quantize=False,
                 first_layer=False,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 clip_max_value=6.0,
                 auto_threshold=True,
                 target_device="Txx"):
        super(BatchNorm, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        self.BatchNorm2d = batchNorm2d(in_channels)
        self.epsilon = self.BatchNorm2d.batch_norm.eps
        self.in_channels = in_channels
        self.activation_fn = activation_fn
        self.is_prelu = False
        self.negslop = None
        self.is_hsigmoid = False

        self.is_check = False
        global input_index
        op_attr = '{"op_type":"input","attr":"input_index_%d"}' % (input_index)
        input_index = input_index + 1
        self.n_op_in = NOp(op_target="input",
                           op_attr=op_attr,
                           target_device=target_device)

        self.flag = quantize
        if activation_fn is not None:
            self.activation_fn = activation_fn
            if 'PReLU' in str(activation_fn) or 'LeakyReLU' in str(
                    activation_fn):
                clip_min_value = -clip_max_value
                self.is_prelu = True
                if 'LeakyReLU' in str(activation_fn):
                    self.negslop = torch.Tensor(out_channels).fill_(
                        activation_fn.negative_slope)
            elif self.flag:
                self.activation_fn = None
                if 'Linear' in str(activation_fn):
                    clip_min_value = -clip_max_value
                elif "Hsigmoid" in str(activation_fn):
                    self.is_hsigmoid = True
                    self.hsigmoid_offset = activation_fn.offset_value

        self.first_layer = first_layer
        self.cflag = True
        self.is_fixpoint = True
        self.QuantizeBatchNorm = QuantizeBatchNorm(in_channels,
                                               input_bitwidth=input_bitwidth,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=0.0,
                                               clip_max_value=clip_max_value,
                                               first_layer=first_layer,
                                               epsilon = self.epsilon,
                                               is_fixpoint=self.is_fixpoint,
                                               target_device=target_device)


    def forward(self, x):
        if self.first_layer:
            if not isinstance(x, tuple):
                logging.error(
                    "you must use ops.Preprocess func; example: ops.Preprocess(mean = 0.0, var = 255.0)(x)"
            )
                exit()
            out, self.QuantizeBatchNorm.input_bitwidth, _, self.img_var, clip_min_pre = x
        elif isinstance(x, tuple):
            out = x[0]
            self.QuantizeBatchNorm.input_bitwidth = x[1]
            clip_min_pre = float(x[2])
            if (clip_min_pre < 0):
                self.img_var = float(2**(x[1] - 1) - 1)
            else:
                self.img_var = float(2**(x[1]) - 1)

        bit = self.QuantizeBatchNorm.input_bitwidth
        self.QuantizeBatchNorm.output_bitwidth = self.QuantizeBatchNorm.input_bitwidth

        if not self.training and self.first_layer:
            out = self.n_op_in(out)

        if (clip_min_pre < 0. and self.cflag):
            self.QuantizeBatchNorm.clip_min_value = -self.QuantizeBatchNorm.clip_max_value
            self.cflag = False

        if self.flag:
            res = out.clone().detach().requires_grad_(False)
            self.one_tensor = torch.ones(self.in_channels).to(out.device)
            self.zero_tensor = torch.zeros(self.in_channels).to(out.device)
            bias = self.zero_tensor.clone().detach()
            wscale = self.one_tensor.clone().detach()
            self.old_mean = self.BatchNorm2d.batch_norm.running_mean.clone(
                            ).detach().requires_grad_(False)
            self.old_var = self.BatchNorm2d.batch_norm.running_var.clone(
                           ).detach().requires_grad_(False)
            out, a, b = self.BatchNorm2d(out)
            alpha = a.clone().detach().requires_grad_(False)
            beta = b.clone().detach().requires_grad_(False)
            if self.is_fixpoint and self.training:
                new_mean, new_var = self.BatchNorm2d.batch_norm.running_mean, self.BatchNorm2d.batch_norm.running_var
                moving_mean = 10. * (new_mean - 0.9 * self.old_mean)
                moving_var = 10. * (new_var - 0.9 * self.old_var)
            else:
                moving_mean = self.BatchNorm2d.batch_norm.running_mean.clone(
                              ).detach().requires_grad_(False)
                moving_var = self.BatchNorm2d.batch_norm.running_var.clone(
                             ).detach().requires_grad_(False)
            prelu_alpha_qf = self.one_tensor.clone().detach()
            if self.activation_fn != None and not self.is_hsigmoid:
                out = self.activation_fn(out)
                if self.is_prelu:
                    prelu_alpha_qf = self.negslop if (
                        self.negslop is not None) else self.activation_fn.prelu.weight
                    prelu_alpha_qf = prelu_alpha_qf.to(out.device)
            elif self.is_hsigmoid:
                out += self.hsigmoid_offset
                beta += self.hsigmoid_offset

            out = self.QuantizeBatchNorm([
                out, alpha, beta, moving_mean, moving_var, res,
                prelu_alpha_qf, self.img_var, clip_min_pre])
        else:
            out, a, b = self.BatchNorm2d(out)
            if self.activation_fn != None:
                out = self.activation_fn(out)

        return (out, self.QuantizeBatchNorm.output_bitwidth,
                    self.QuantizeBatchNorm.clip_min_value)


class ConvTranspose2D(nn.Module):
    def __init__(self,
                 in_channels,
                 out_channels,
                 activation_fn=ReLU6(),
                 enable_batch_norm=False,
                 enable_bias=True,
                 data_format="NCHW",
                 quantize=False,
                 quantize_last_feature=False,
                 last_layer=False,
                 weight_bitwidth=32,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 clip_max_value=6.0,
                 weight_factor=3.0,
                 target_device="Txx",
                 auto_bitwidth=True,
                 auto_threshold=False,
                 pre_lstm_layer=False):
        super(ConvTranspose2D, self).__init__()
        assert data_format == "NCHW"
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]

        self.Unpool2D = Unpool2D(mode="nearest", target_device=target_device)
        if target_device in ["Txx", "Xs1", "Xs2"]:
            self.DepthwiseConv2D = DepthwiseConv2D(
                in_channels,
                1,
                activation_fn=activation_fn,
                enable_batch_norm=enable_batch_norm,
                padding=1,
                enable_bias=enable_bias,
                data_format=data_format,
                quantize=quantize,
                quantize_last_feature=quantize_last_feature,
                last_layer=False,
                weight_factor=weight_factor,
                clip_max_value=clip_max_value,
                input_bitwidth=input_bitwidth,
                weight_bitwidth=weight_bitwidth,
                output_bitwidth=output_bitwidth,
                target_device=target_device,
                auto_bitwidth=auto_bitwidth,
                auto_threshold=auto_threshold)
            self.Conv2D = Conv2D(in_channels,
                                 out_channels,
                                 1,
                                 1,
                                 1,
                                 activation_fn=activation_fn,
                                 enable_batch_norm=enable_batch_norm,
                                 enable_bias=enable_bias,
                                 data_format=data_format,
                                 quantize=quantize,
                                 quantize_last_feature=quantize_last_feature,
                                 last_layer=last_layer,
                                 weight_factor=weight_factor,
                                 clip_max_value=clip_max_value,
                                 input_bitwidth=input_bitwidth,
                                 weight_bitwidth=weight_bitwidth,
                                 output_bitwidth=output_bitwidth,
                                 target_device=target_device,
                                 auto_bitwidth=auto_bitwidth,
                                 auto_threshold=auto_threshold,
                                 pre_lstm_layer=pre_lstm_layer)
        elif target_device in ["T40"]:
            self.Conv2D = Conv2D(in_channels,
                                 out_channels,
                                 1,
                                 activation_fn=activation_fn,
                                 enable_batch_norm=enable_batch_norm,
                                 enable_bias=enable_bias,
                                 data_format=data_format,
                                 quantize=quantize,
                                 quantize_last_feature=quantize_last_feature,
                                 last_layer=last_layer,
                                 weight_factor=weight_factor,
                                 clip_max_value=clip_max_value,
                                 input_bitwidth=input_bitwidth,
                                 weight_bitwidth=weight_bitwidth,
                                 output_bitwidth=output_bitwidth,
                                 target_device=target_device,
                                 auto_bitwidth=auto_bitwidth,
                                 auto_threshold=auto_threshold,
                                 pre_lstm_layer=pre_lstm_layer)
        self.target_device = target_device

    def forward(self, input):
        out = self.Unpool2D(input)
        if self.target_device in ["Txx", "Xs1", "Xs2"]:
            out = self.DepthwiseConv2D(out)
            out = self.Conv2D(out)
        elif self.target_device in ["T40"]:
            out = self.Conv2D(out)

        return out


class Conv2D(nn.Module):
    def __init__(self,
                 in_channels,
                 out_channels,
                 stride=1,
                 kernel_h=3,
                 kernel_w=3,
                 activation_fn=ReLU6(),
                 enable_batch_norm=False,
                 enable_bias=True,
                 padding=0,
                 groups=1,
                 dilation=1,
                 data_format="NCHW",
                 quantize=False,
                 quantize_last_feature=False,
                 first_layer=False,
                 last_layer=False,
                 weight_bitwidth=32,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 clip_max_value=6.0,
                 weight_factor=3.0,
                 target_device="Txx",
                 auto_bitwidth=True,
                 is_focus=False,
                 auto_threshold=False,
                 pre_lstm_layer=False):
        super(Conv2D, self).__init__()
        assert data_format == "NCHW"
        assert target_device in ["T02", "Txx", "Xs1", "Xs2", "T40"]
        if dilation > 1:
            if target_device not in ["Txx", "Xs1", "Xs2"]:
                logging.error("dilation > 1 is not supported.")
            else:
                logging.error(
                    "dilation > 1 is not currently supported, will be supported in the future."
                )
            exit(0)
        if groups > 1:
            if target_device in ["T40"]:
                if (in_channels // groups) % 32 != 0 or (out_channels // groups) % 32 != 0:
                    logging.error(
                        "%s, %s - Please check your channels, in/out channels must be divisible by 32" % ("Conv2D", str(groups)))
                    exit(0)
        if target_device in [
                "Txx", "Xs1", "Xs2"
        ] and (weight_bitwidth < 8 or output_bitwidth < 8) and auto_bitwidth:
            if kernel_h == 1:
                assert out_channels <= 512
                if out_channels < 128:
                    output_bitwidth = 5
                else:
                    output_bitwidth = 4
                if in_channels <= 128:
                    weight_bitwidth = 5
                else:
                    weight_bitwidth = 4
            elif kernel_h == 2:
                weight_bitwidth = 4
                assert out_channels <= 128
                if out_channels <= 64:
                    output_bitwidth = 5
                else:
                    output_bitwidth = 4
            else:
                weight_bitwidth = 4
                assert out_channels <= 64
                if out_channels <= 32:
                    output_bitwidth = 5
                else:
                    output_bitwidth = 4
            if first_layer:
                input_bitwidth = 8
                if out_channels < 32:
                    output_bitwidth = 5
                else:
                    output_bitwidth = 4
            elif last_layer:
                output_bitwidth = 32

        clip_min_value = 0.0
        self.quantize = quantize
        self.enable_batch_norm = enable_batch_norm
        self.enable_bias = enable_bias
        self.padding = padding
        self.is_prelu = False
        self.negslop = None
        self.is_hsigmoid = False

        kernel_size = (kernel_h, kernel_w)

        self.is_check = True
        self.first_layer = first_layer
        if first_layer:
            self.is_check = False
            global input_index
            op_attr = '{"op_type":"input","attr":"input_index_%d"}' % (input_index)
            input_index = input_index + 1
            self.n_op_in = NOp(op_target="input",
                            op_attr=op_attr,
                            target_device=target_device)

        if target_device == "T02":
            assert kernel_h == kernel_w == 3
        self.target_device = target_device
        self.activation_fn = activation_fn

        if quantize:
            self.Conv2d = Conv2d_Q(
                in_channels,
                out_channels,
                kernel_size,
                stride,
                padding,
                dilation,
                groups,
                enable_bias,
                weight_bitwidth,
                weight_factor,
                target_device=target_device)  ##dilation=1 groups
        else:
            self.Conv2d = nn.Conv2d(in_channels, out_channels, kernel_size,
                                    stride, padding, dilation, groups,
                                    enable_bias)  ##dilation=1 groups

        epsilon = 0.
        if enable_batch_norm:
            self.BatchNorm2d = batchNorm2d(out_channels)
            epsilon = self.BatchNorm2d.batch_norm.eps

        self.flag = False
        if quantize:
            if not last_layer:
                self.flag = True
            elif quantize_last_feature:
                self.flag = True

        if activation_fn is not None:
            self.activation_fn = activation_fn
            if 'PReLU' in str(activation_fn) or 'LeakyReLU' in str(
                    activation_fn):
                clip_min_value = -clip_max_value
                self.is_prelu = True
                if 'LeakyReLU' in str(activation_fn):
                    self.negslop = torch.Tensor(out_channels).fill_(
                        activation_fn.negative_slope)
            elif self.flag:
                self.activation_fn = None
                if 'Linear' in str(activation_fn):
                    clip_min_value = -clip_max_value
                elif "Hsigmoid" in str(activation_fn):
                    self.is_hsigmoid = True
                    self.hsigmoid_offset = activation_fn.offset_value

        self.output_bitwidth = output_bitwidth
        self.weight_bitwidth = weight_bitwidth
        self.kernel_h = kernel_h
        self.kernel_w = kernel_w
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.is_fixpoint = True
        self.QuantizeFeature = QuantizeFeature(self.in_channels,
                                               out_channels,
                                               weight_bitwidth,
                                               input_bitwidth,
                                               output_bitwidth,
                                               float(clip_min_value),
                                               float(clip_max_value),
                                               epsilon,
                                               first_layer,
                                               self.is_fixpoint,
                                               auto_threshold,
                                               self.is_prelu,
                                               False,
                                               pre_lstm_layer=pre_lstm_layer,
                                               target_device=target_device)
        self.last_layer = last_layer
        if last_layer:
            self.is_check = False
        self.is_focus = is_focus
        if is_focus:
            self.Focus = Focus(target_device)
        self.clip_min_value = clip_min_value

    def forward(self, x):
        if self.quantize and not self.last_layer and not self.training and self.target_device in ["T40", "T02"]:
            res = quantize_conv2d_inference(x, self)
            return (res, self.output_bitwidth, self.clip_min_value)
        clip_min_pre = 0.
        if self.first_layer:
            if not isinstance(x, tuple):
                logging.error(
                    "you must use ops.Preprocess func; example: ops.Preprocess(inputs, mean = 0.0, var = 255.0)(x)"
                )
                exit()
            input, self.QuantizeFeature.input_bitwidth, _, self.img_var, clip_min_pre = x
        elif isinstance(x, tuple):
            input = x[0]
            self.QuantizeFeature.input_bitwidth = x[1]
            clip_min_pre = float(x[2])
            if (clip_min_pre < 0):
                self.img_var = float(2**(x[1] - 1) - 1)
            else:
                self.img_var = float(2**(x[1]) - 1)
        else:
            input = x

        if self.target_device in [
                "Txx", "Xs1", "Xs2"
        ] and self.weight_bitwidth < 8 and self.is_check:
            if (self.kernel_h * self.kernel_w *
                    pow(2, self.QuantizeFeature.input_bitwidth) *
                    pow(2, self.weight_bitwidth - 1) * self.in_channels >
                    73728):
                logging.error(
                    "Conv2D-Please check your bitwidth, they are out of bounds, kernel:%d, in_channels:%d, input_bitwidth:%d, weight_bitwidth:%d"
                    % (self.kernel_h, self.in_channels,
                       self.QuantizeFeature.input_bitwidth,
                       self.weight_bitwidth))
                exit()
            if not (self.QuantizeFeature.input_bitwidth >= 4 and
                    self.output_bitwidth >= 4 and self.weight_bitwidth >= 4):
                logging.error(
                    "Conv2D-All the bitwidth should greater than or equal to 4, but now the are input_bitwidth:%d, weight_bitwidth:%d, output_bitwidth:%d"
                    % (self.QuantizeFeature.input_bitwidth,
                       self.weight_bitwidth, self.output_bitwidth))
                exit()
            self.is_check = False

        if not self.training and self.first_layer:
            input = self.n_op_in(input)

        if self.is_focus:
            input = self.Focus(input)

        if self.target_device == "T02":
            self.Conv2d.padding = (1, 1)
        elif (self.padding):
            if not self.first_layer and self.target_device == "T40" and clip_min_pre < 0.:
                input = get_padding(input, self.Conv2d.kernel_size,
                                    self.Conv2d.stride, -1.)
            else:
                input = get_padding(input, self.Conv2d.kernel_size,
                                    self.Conv2d.stride)
            self.Conv2d.padding = (0, 0)

        if self.quantize:
            wscale = torch.zeros(self.out_channels, device=input.device)
            out, conv_bias, wscale, conv_res = self.Conv2d([input, wscale])
            if not self.enable_bias:
                conv_bias = torch.zeros(self.out_channels, device=input.device)
        else:
            out = self.Conv2d(input)

        if self.flag:
            if self.enable_batch_norm:
                self.old_mean = self.BatchNorm2d.batch_norm.running_mean.clone(
                ).detach().requires_grad_(False)
                self.old_var = self.BatchNorm2d.batch_norm.running_var.clone(
                ).detach().requires_grad_(False)
                out, a, b = self.BatchNorm2d(out)
                alpha = a.clone().detach().requires_grad_(False)
                beta = b.clone().detach().requires_grad_(False)
                if self.is_fixpoint and self.training:
                    new_mean, new_var = self.BatchNorm2d.batch_norm.running_mean, self.BatchNorm2d.batch_norm.running_var
                    moving_mean = 10. * (new_mean - 0.9 * self.old_mean)
                    moving_var = 10. * (new_var - 0.9 * self.old_var)
                else:
                    moving_mean = self.BatchNorm2d.batch_norm.running_mean.clone(
                    ).detach().requires_grad_(False)
                    moving_var = self.BatchNorm2d.batch_norm.running_var.clone(
                    ).detach().requires_grad_(False)
            else:
                alpha = torch.ones(self.out_channels, device=input.device)
                beta = torch.zeros(self.out_channels, device=input.device)
                moving_mean = torch.zeros(self.out_channels,
                                          device=input.device)
                moving_var = torch.ones(self.out_channels, device=input.device)

            prelu_alpha_qf = torch.ones(self.out_channels, device=input.device)
            if self.activation_fn != None and not self.is_hsigmoid:
                out = self.activation_fn(out)
                if self.is_prelu:
                    prelu_alpha_qf = self.negslop if (
                        self.negslop is not None) else self.activation_fn.prelu.weight
                    prelu_alpha_qf = prelu_alpha_qf.to(input.device)
            elif self.is_hsigmoid:
                out += self.hsigmoid_offset
                beta += self.hsigmoid_offset
            out = self.QuantizeFeature([
                out, conv_bias, wscale, alpha, beta, moving_mean, moving_var,
                prelu_alpha_qf, conv_res, self.img_var, clip_min_pre
            ])
        else:
            if self.enable_batch_norm:
                out, a, b = self.BatchNorm2d(out)
            if self.activation_fn != None:
                out = self.activation_fn(out)

        if not self.training and self.last_layer:
            global index
            op_attr = '{"op_type":"output","attr":"index_%d"}' % (index)
            index = index + 1
            self.n_op_out = NOp(op_target="output",
                                op_attr=op_attr,
                                target_device=self.target_device)
            out = self.n_op_out(out)

        if self.last_layer:
            return out
        else:
            return (out, self.output_bitwidth, self.clip_min_value)


class DepthwiseConv2D(nn.Module):
    def __init__(self,
                 in_channels,
                 stride=1,
                 kernel_h=3,
                 kernel_w=3,
                 activation_fn=ReLU6(),
                 enable_batch_norm=False,
                 enable_bias=True,
                 padding=0,
                 data_format="NCHW",
                 quantize=False,
                 quantize_last_feature=False,
                 last_layer=False,
                 weight_bitwidth=32,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 clip_max_value=6.0,
                 weight_factor=3.0,
                 target_device="Txx",
                 auto_bitwidth=True,
                 auto_threshold=False,
                 pre_lstm_layer=False):
        super(DepthwiseConv2D, self).__init__()
        assert data_format == "NCHW"
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        if target_device in [
                "Txx", "Xs1", "Xs2"
        ] and (weight_bitwidth < 8 or output_bitwidth < 8) and auto_bitwidth:
            weight_bitwidth = 8
            assert in_channels <= 512
            if in_channels < 128:
                output_bitwidth = 5
            else:
                output_bitwidth = 4
        if last_layer:
            output_bitwidth = 32

        clip_min_value = 0.0
        self.quantize = quantize
        self.enable_batch_norm = enable_batch_norm
        self.enable_bias = enable_bias
        self.padding = padding
        self.is_prelu = False
        self.negslop = None
        self.is_hsigmoid = False

        kernel_size = (kernel_h, kernel_w)
        out_channels = in_channels
        self.in_channels = in_channels
        self.kernel_h = kernel_h
        self.kernel_w = kernel_w
        self.target_device = target_device
        self.pre_lstm_layer = pre_lstm_layer
        if quantize:
            weigth_target_device = self.target_device
            if weigth_target_device == "T40":
                weigth_target_device = "Txx"
            self.Conv2d = Conv2d_Q(
                in_channels, out_channels, kernel_size, stride, padding, 1,
                in_channels, enable_bias, weight_bitwidth, weight_factor,
                weigth_target_device)  ##dilation=1 groups=in_channels
        else:
            self.Conv2d = nn.Conv2d(
                in_channels, out_channels, kernel_size, stride, padding, 1,
                in_channels, enable_bias)  ##dilation=1 groups=in_channels

        epsilon = 0.
        if enable_batch_norm:
            self.BatchNorm2d = batchNorm2d(out_channels)
            epsilon = self.BatchNorm2d.batch_norm.eps

        self.flag = False
        if quantize:
            if not last_layer:
                self.flag = True
            elif quantize_last_feature:
                self.flag = True
        self.activation_fn = activation_fn
        if activation_fn is not None:
            self.activation_fn = activation_fn
            if 'PReLU' in str(activation_fn) or 'LeakyReLU' in str(
                    activation_fn):
                clip_min_value = -clip_max_value
                self.is_prelu = True
                if 'LeakyReLU' in str(activation_fn):
                    self.negslop = torch.Tensor(out_channels).fill_(
                        activation_fn.negative_slope)
            elif self.flag:
                self.activation_fn = None
                if 'Linear' in str(activation_fn):
                    clip_min_value = -clip_max_value
                elif "Hsigmoid" in str(activation_fn):
                    self.is_hsigmoid = True
                    self.hsigmoid_offset = activation_fn.offset_value

        self.is_check = True
        self.out_channels = out_channels
        self.output_bitwidth = output_bitwidth
        self.weight_bitwidth = weight_bitwidth
        self.is_fixpoint = True
        self.QuantizeFeature = QuantizeFeature(
            in_channels,
            out_channels,
            weight_bitwidth,
            input_bitwidth,
            output_bitwidth,
            float(clip_min_value),
            float(clip_max_value),
            epsilon,
            False,
            self.is_fixpoint,
            auto_threshold,
            self.is_prelu,
            False,
            pre_lstm_layer=self.pre_lstm_layer,
            target_device=target_device)
        self.last_layer = last_layer
        if last_layer:
            self.is_check = False
        self.clip_min_value = clip_min_value
        self.first_layer = False
        self.is_focus = False

    def forward(self, x):
        if self.quantize and not self.last_layer and not self.training and self.target_device in ["T40", "T02"]:
            res = quantize_conv2d_inference(x, self)
            return (res, self.output_bitwidth, self.clip_min_value)
        clip_min_pre = 0.
        if isinstance(x, tuple):
            input = x[0]
            self.QuantizeFeature.input_bitwidth = x[1]
            clip_min_pre = float(x[2])
        else:
            input = x

        if self.target_device in [
                "Txx", "Xs1", "Xs2"
        ] and self.weight_bitwidth < 8 and self.is_check:
            if (self.kernel_h * self.kernel_w *
                    pow(2, self.QuantizeFeature.input_bitwidth) *
                    pow(2, self.weight_bitwidth - 1) > 65536):
                logging.error(
                    "DepthwiseConv2D-Please check your bitwidth, they are out of bounds, kernel:%d, in_channels:%d, input_bitwidth:%d, weight_bitwidth:%d"
                    % (self.kernel_h, self.in_channels,
                       self.QuantizeFeature.input_bitwidth,
                       self.weight_bitwidth))
                exit()
            if not (self.QuantizeFeature.input_bitwidth >= 4 and
                    self.output_bitwidth >= 4 and self.weight_bitwidth >= 4):
                logging.error(
                    "DepthwiseConv2D-All the bitwidth should greater than or equal to 4, but now the are input_bitwidth:%d, weight_bitwidth:%d, output_bitwidth:%d"
                    % (self.QuantizeFeature.input_bitwidth,
                       self.weight_bitwidth, self.output_bitwidth))
                exit()
            self.is_check = False

        if (clip_min_pre < 0):
            self.img_var = float(2**(x[1] - 1) - 1)
        else:
            self.img_var = float(2**(x[1]) - 1)

        if self.padding:
            if self.target_device == "T40" and clip_min_pre < 0.:
                input = get_padding(input, self.Conv2d.kernel_size,
                                    self.Conv2d.stride, -1.)
            else:
                input = get_padding(input, self.Conv2d.kernel_size,
                                    self.Conv2d.stride)
            self.Conv2d.padding = (0, 0)

        if self.quantize:
            wscale = torch.zeros(self.out_channels, device=input.device)
            out, conv_bias, wscale, conv_res = self.Conv2d([input, wscale])
            if not self.enable_bias:
                conv_bias = torch.zeros(self.out_channels, device=input.device)
        else:
            out = self.Conv2d(input)

        if self.flag:
            if self.enable_batch_norm:
                self.old_mean = self.BatchNorm2d.batch_norm.running_mean.clone(
                ).detach().requires_grad_(False)
                self.old_var = self.BatchNorm2d.batch_norm.running_var.clone(
                ).detach().requires_grad_(False)
                out, a, b = self.BatchNorm2d(out)
                alpha = a.clone().detach().requires_grad_(False)
                beta = b.clone().detach().requires_grad_(False)
                if self.is_fixpoint and self.training:
                    new_mean, new_var = self.BatchNorm2d.batch_norm.running_mean, self.BatchNorm2d.batch_norm.running_var
                    moving_mean = 10. * (new_mean - 0.9 * self.old_mean)
                    moving_var = 10. * (new_var - 0.9 * self.old_var)
                else:
                    moving_mean = self.BatchNorm2d.batch_norm.running_mean.clone(
                    ).detach().requires_grad_(False)
                    moving_var = self.BatchNorm2d.batch_norm.running_var.clone(
                    ).detach().requires_grad_(False)
            else:
                alpha = torch.ones(self.out_channels, device=input.device)
                beta = torch.zeros(self.out_channels, device=input.device)
                moving_mean = torch.zeros(self.out_channels,
                                          device=input.device)
                moving_var = torch.ones(self.out_channels, device=input.device)
            prelu_alpha_qf = torch.ones(self.out_channels, device=input.device)
            if self.activation_fn != None and not self.is_hsigmoid:
                out = self.activation_fn(out)
                if self.is_prelu:
                    prelu_alpha_qf = self.negslop if (
                        self.negslop is not None) else self.activation_fn.prelu.weight
                    prelu_alpha_qf = prelu_alpha_qf.to(input.device)
            elif self.is_hsigmoid:
                out += self.hsigmoid_offset
                beta += self.hsigmoid_offset
            out = self.QuantizeFeature([
                out, conv_bias, wscale, alpha, beta, moving_mean, moving_var,
                prelu_alpha_qf, conv_res, self.img_var, clip_min_pre
            ])
        else:
            if self.enable_batch_norm:
                out, a, b = self.BatchNorm2d(out)
            if self.activation_fn != None:
                out = self.activation_fn(out)

        if not self.training and self.last_layer:
            global index
            op_attr = '{"op_type":"output","attr":"index_%d"}' % (index)
            index = index + 1
            self.n_op_out = NOp(op_target="output",
                                op_attr=op_attr,
                                target_device=self.target_device)
            out = self.n_op_out(out)

        if self.last_layer:
            return out
        else:
            return (out, self.output_bitwidth, self.clip_min_value)


class FullConnected(nn.Module):
    def __init__(self,
                 in_channels,
                 out_channels,
                 activation_fn=ReLU6(),
                 enable_batch_norm=False,
                 enable_bias=True,
                 data_format="NCHW",
                 quantize=False,
                 quantize_last_feature=False,
                 last_layer=False,
                 weight_bitwidth=32,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 clip_max_value=6.0,
                 weight_factor=3.0,
                 target_device="Txx",
                 auto_bitwidth=True,
                 auto_threshold=False,
                 pre_lstm_layer=False):
        super(FullConnected, self).__init__()
        assert target_device in ["T02", "Txx", "Xs1", "Xs2", "T40"]
        if target_device in [
                "Txx", "Xs1", "Xs2"
        ] and (weight_bitwidth < 8 or output_bitwidth < 8) and auto_bitwidth:
            assert out_channels <= 512
            if out_channels < 128:
                output_bitwidth = 5
            else:
                output_bitwidth = 4
            if in_channels <= 128:
                weight_bitwidth = 5
            else:
                weight_bitwidth = 4
        if last_layer:
            output_bitwidth = 32

        clip_min_value = 0.0
        self.quantize = quantize
        self.enable_batch_norm = enable_batch_norm
        self.enable_bias = enable_bias
        self.activation_fn = activation_fn
        self.is_prelu = False
        self.negslop = None
        self.is_hsigmoid = False

        if quantize:
            self.Linear = Linear_Q(in_channels,
                                   out_channels,
                                   enable_bias,
                                   weight_bitwidth,
                                   weight_factor,
                                   target_device=target_device)
        else:
            self.Linear = nn.Linear(in_channels, out_channels, enable_bias)

        epsilon = 0.
        if enable_batch_norm:
            self.BatchNorm1d = batchNorm1d(out_channels)
            epsilon = self.BatchNorm1d.batch_norm.eps

        self.flag = False
        if quantize:
            if last_layer == False:
                self.flag = True
            elif quantize_last_feature:
                self.flag = True

        if activation_fn is not None:
            self.activation_fn = activation_fn
            if 'PReLU' in str(activation_fn) or 'LeakyReLU' in str(
                    activation_fn):
                clip_min_value = -clip_max_value
                self.is_prelu = True
                if 'LeakyReLU' in str(activation_fn):
                    self.negslop = torch.Tensor(out_channels).fill_(
                        activation_fn.negative_slope)
            elif self.flag:
                self.activation_fn = None
                if 'Linear' in str(activation_fn):
                    clip_min_value = -clip_max_value
                elif "Hsigmoid" in str(activation_fn):
                    self.is_hsigmoid = True
                    self.hsigmoid_offset = activation_fn.offset_value

        self.is_check = True
        self.target_device = target_device
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.output_bitwidth = output_bitwidth
        self.weight_bitwidth = weight_bitwidth
        self.is_fixpoint = True
        self.pre_lstm_layer = pre_lstm_layer
        self.QuantizeFeature = QuantizeFeature(
            in_channels,
            out_channels,
            weight_bitwidth,
            input_bitwidth,
            output_bitwidth,
            float(clip_min_value),
            float(clip_max_value),
            epsilon,
            False,
            self.is_fixpoint,
            auto_threshold,
            self.is_prelu,
            False,
            pre_lstm_layer=self.pre_lstm_layer,
            target_device=target_device,
            data_format=data_format)
        self.last_layer = last_layer
        if last_layer:
            self.is_check = False
        self.clip_min_value = clip_min_value

    def forward(self, x):
        clip_min_pre = 0.
        if isinstance(x, tuple):
            input = x[0]
            self.QuantizeFeature.input_bitwidth = x[1]
            clip_min_pre = float(x[2])
        else:
            input = x

        if self.target_device in [
                "Txx", "Xs1", "Xs2"
        ] and self.weight_bitwidth < 8 and self.is_check:
            if (pow(2, self.QuantizeFeature.input_bitwidth) *
                    pow(2, self.weight_bitwidth - 1) * self.in_channels >
                    65536):
                logging.error(
                    "FullConnected-Please check your bitwidth, they are out of bounds, in_channels:%d, input_bitwidth:%d, weight_bitwidth:%d"
                    % (self.in_channels, self.QuantizeFeature.input_bitwidth,
                       self.weight_bitwidth))
                exit()
            if not (self.QuantizeFeature.input_bitwidth >= 4 and
                    self.output_bitwidth >= 4 and self.weight_bitwidth >= 4):
                logging.error(
                    "FullConnected-All the bitwidth should greater than or equal to 4, but now the are input_bitwidth:%d, weight_bitwidth:%d, output_bitwidth:%d"
                    % (self.QuantizeFeature.input_bitwidth,
                       self.weight_bitwidth, self.output_bitwidth))
                exit()
            self.is_check = True
        if (clip_min_pre < 0):
            self.img_var = float(2**(x[1] - 1) - 1)
        else:
            self.img_var = float(2**(x[1]) - 1)

        if self.quantize:
            wscale = torch.zeros(self.out_channels, device=input.device)
            out, linear_bias, wscale, conv_res = self.Linear([input, wscale])
            if not self.enable_bias:
                linear_bias = torch.zeros(self.out_channels,
                                          device=input.device)
        else:
            out = self.Linear(input)

        if len(input.shape) >= 3:
            self.QuantizeFeature.data_format = "NHWC"

        if self.flag:
            if self.enable_batch_norm:
                self.old_mean = self.BatchNorm1d.batch_norm.running_mean.clone(
                ).detach().requires_grad_(False)
                self.old_var = self.BatchNorm1d.batch_norm.running_var.clone(
                ).detach().requires_grad_(False)
                out, a, b = self.BatchNorm1d(out)
                alpha = a.clone().detach().requires_grad_(False)
                beta = b.clone().detach().requires_grad_(False)
                if self.is_fixpoint and self.training:
                    new_mean, new_var = self.BatchNorm1d.batch_norm.running_mean, self.BatchNorm1d.batch_norm.running_var
                    moving_mean = 10. * (new_mean - 0.9 * self.old_mean)
                    moving_var = 10. * (new_var - 0.9 * self.old_var)
                else:
                    moving_mean = self.BatchNorm1d.batch_norm.running_mean.clone(
                    ).detach().requires_grad_(False)
                    moving_var = self.BatchNorm1d.batch_norm.running_var.clone(
                    ).detach().requires_grad_(False)
            else:
                alpha = torch.ones(self.out_channels, device=input.device)
                beta = torch.zeros(self.out_channels, device=input.device)
                moving_mean = torch.zeros(self.out_channels,
                                          device=input.device)
                moving_var = torch.ones(self.out_channels, device=input.device)
            prelu_alpha_qf = torch.ones(self.out_channels, device=input.device)
            if self.activation_fn != None and not self.is_hsigmoid:
                out = self.activation_fn(out)
                if self.is_prelu:
                    prelu_alpha_qf = self.negslop if (
                        self.negslop is not None) else self.activation_fn.prelu.weight
                    prelu_alpha_qf = prelu_alpha_qf.to(input.device)
            elif self.is_hsigmoid:
                out += self.hsigmoid_offset
                beta += self.hsigmoid_offset
            out = self.QuantizeFeature([
                out, linear_bias, wscale, alpha, beta, moving_mean, moving_var,
                prelu_alpha_qf, conv_res, self.img_var, clip_min_pre
            ])
        else:
            if self.enable_batch_norm:
                out, a, b = self.BatchNorm1d(out)
            if self.activation_fn != None:
                out = self.activation_fn(out)

        if not self.training and self.last_layer:
            global index
            op_attr = '{"op_type":"output","attr":"index_%d"}' % (index)
            index = index + 1
            self.n_op_out = NOp(op_target="output",
                                op_attr=op_attr,
                                target_device=self.target_device)
            out = self.n_op_out(out)

        if self.last_layer:
            return out
        else:
            return (out, self.output_bitwidth, self.clip_min_value)


class Flatten(nn.Module):
    def __init__(self, shape_list, target_device="Txx"):
        super(Flatten, self).__init__()
        assert target_device in ["T02", "Txx", "Xs1", "Xs2", "T40"]
        self.shape_list = shape_list

        op_attr = '{"op_type":"Flatten"}'
        self.n_op_start = NOp("flatten_start", op_attr, target_device)
        self.n_op_end = NOp("flatten_end", op_attr, target_device)

    def forward(self, x):
        if isinstance(x, tuple):
            input = x[0]
            bitwidth = x[1]
        else:
            input = x

        if not self.training:
            input = self.n_op_start(input)
        out = torch.reshape(input, self.shape_list)
        if not self.training:
            out = self.n_op_end(out)

        if isinstance(x, tuple):
            return (out, bitwidth, x[2])
        else:
            return out


class Route(nn.Module):
    def __init__(self, target_device="Txx"):
        super(Route, self).__init__()
        assert target_device in ["T02", "Txx", "Xs1", "Xs2", "T40"]
        self.target_device = target_device

    def forward(self, x):
        if isinstance(x[0], tuple):  # and isinstance(x[1], tuple):
            input = [x[i][0] for i in range(len(x))]
            input_bitwidth = [x[i][1] for i in range(len(x))]
            input_min_value = [x[i][2]>0 for i in range(len(x))]
            if len(set(input_bitwidth)) != 1:
                logging.error(
                    "Please check your input bit width of Route, all input bit widths should be the same!"
                )
                exit(0)
            if len(set(input_min_value)) != 1:
                logging.error(
                    "Please check your input min value of Route, all input min value should be the same!"
                )
                exit(0)
            bitwidth = x[0][1]
            clip_min_pre = x[0][2]
        else:
            input = x

        if (self.target_device == "T02"):
            assert len(input) <= 8

        output = torch.cat(input, 1)
        if isinstance(x[0], tuple):
            return (output, bitwidth, clip_min_pre)
        else:
            return output


class Maxpool2D(nn.Module):
    def __init__(self,
                 kernel_h=2,
                 kernel_w=2,
                 stride=2,
                 padding=0,
                 target_device="Txx"):
        super(Maxpool2D, self).__init__()
        assert target_device in ["T02", "Txx", "Xs1", "Xs2", "T40"]
        if target_device == "T02":
            assert stride == 2
            assert kernel_h == kernel_w == 2
            assert padding == 0

        self.target_device = target_device
        self.padding = padding
        self.maxpool2d = nn.MaxPool2d((kernel_h, kernel_w),
                                      stride=stride,
                                      padding=padding)

    def forward(self, x):
        clip_min_pre = 0.
        if isinstance(x, tuple):
            input = x[0]
            bitwidth = x[1]
            clip_min_pre = x[2]
        else:
            input = x

        if (self.padding):
            if self.target_device == "T40" and clip_min_pre < 0.:
                input = get_padding(input, self.maxpool2d.kernel_size,
                                    self.maxpool2d.stride, -1.)
            else:
                input = get_padding(input, self.maxpool2d.kernel_size,
                                    self.maxpool2d.stride)
            self.maxpool2d.padding = (0, 0)

        out = self.maxpool2d(input)
        if isinstance(x, tuple):
            return (out, bitwidth, x[2])
        else:
            return out


class Avgpool2D(nn.Module):
    def __init__(self,
                 in_channels,
                 kernel_h=2,
                 kernel_w=2,
                 stride=2,
                 padding=0,
                 quantize=False,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 target_device="Txx"):
        super(Avgpool2D, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        self.quantize = quantize
        self.target_device = target_device
        self.padding = padding
        self.avgpool2d = nn.AvgPool2d((kernel_h, kernel_w), stride=stride)
        self.QuantizeFeature = QuantizeFeature(in_channels, in_channels,
                                               input_bitwidth=input_bitwidth,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=0.0,
                                               clip_max_value=1.0,
                                               target_device=target_device)
        self.cflag = True
        self.in_channels = in_channels

    def forward(self, x):
        clip_min_pre = 0.
        if isinstance(x, tuple):
            input = x[0]
            self.QuantizeFeature.input_bitwidth = x[1]
            self.QuantizeFeature.output_bitwidth = self.QuantizeFeature.input_bitwidth
            clip_min_pre = x[2]
        else:
            input = x

        if (torch.min(input) < 0. and self.cflag):
            self.QuantizeFeature.clip_min_value = -1.0
            self.cflag = False
        if self.padding:
            if self.target_device == "T40" and clip_min_pre < 0.:
                input = get_padding(input, self.avgpool2d.kernel_size,
                                    self.avgpool2d.stride, -1.)
            else:
                input = get_padding(input, self.avgpool2d.kernel_size,
                                    self.avgpool2d.stride)
            self.avgpool2d.padding = (0, 0)
        if (clip_min_pre < 0):
            self.img_var = float(2**(x[1] - 1) - 1)
        else:
            self.img_var = float(2**(x[1]) - 1)
        out = self.avgpool2d(input)
        if self.quantize:
            alpha = torch.ones(self.in_channels, device=input.device)
            beta = torch.zeros(self.in_channels, device=input.device)
            out = self.QuantizeFeature(
                [out, alpha, beta, clip_min_pre, self.img_var])
        if isinstance(x, tuple):
            return (out, self.QuantizeFeature.output_bitwidth, self.QuantizeFeature.clip_min_value)
        else:
            return out


class AdaptiveAvgpool2D(nn.Module):
    def __init__(self,
                 in_channels,
                 keepdim=True,
                 quantize=False,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 last_layer=False,
                 target_device="Txx"):
        super(AdaptiveAvgpool2D, self).__init__()
        assert target_device in ["T02", "Txx", "Xs1", "Xs2", "T40"]
        self.quantize = quantize
        self.QuantizeFeature = QuantizeFeature(in_channels, in_channels,
                                               input_bitwidth=input_bitwidth,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=0.0,
                                               clip_max_value=1.0,
                                               target_device=target_device)
        self.cflag = True
        self.in_channels = in_channels
        self.last_layer = last_layer
        self.target_device = target_device
        self.keepdim = keepdim

    def forward(self, x):
        if isinstance(x, tuple):
            input = x[0]
            self.QuantizeFeature.input_bitwidth = x[1]
            self.QuantizeFeature.output_bitwidth = self.QuantizeFeature.input_bitwidth
            clip_min_pre = x[2]
        else:
            input = x
        if (clip_min_pre < 0):
            self.img_var = float(2**(x[1] - 1) - 1)
        else:
            self.img_var = float(2**(x[1]) - 1)
        if (torch.min(input) < 0. and self.cflag):
            self.QuantizeFeature.clip_min_value = -1.0
            self.cflag = False
        out = torch.mean(input, dim=[2, 3], keepdim=self.keepdim)
        if self.quantize:
            alpha = torch.ones(self.in_channels, device=input.device)
            beta = torch.zeros(self.in_channels, device=input.device)
            out = self.QuantizeFeature(
                [out, alpha, beta, clip_min_pre, self.img_var])
        if self.last_layer:
            if not self.training:
                global index
                op_attr = '{"op_type":"output","attr":"index_%d"}' % (index)
                index = index + 1
                self.n_op_out = NOp(op_target="output",
                                    op_attr=op_attr,
                                    target_device=self.target_device)
                out = self.n_op_out(out)
            return out
        if isinstance(x, tuple):
            return (out, self.QuantizeFeature.output_bitwidth, self.QuantizeFeature.clip_min_value)
        else:
            return out


class Unpool2D(nn.Module):
    def __init__(self,
                 kernel_h=2,
                 kernel_w=2,
                 mode="zero",
                 quantize=False,
                 last_layer=False,
                 target_device="Txx"):
        super(Unpool2D, self).__init__()
        assert target_device in ["T02", "Txx", "Xs1", "Xs2", "T40"]
        assert mode in ["zero", "nearest", "bilinear"]
        if target_device == "T02":
            assert kernel_h == kernel_w == 2
        self.target_device = target_device
        self.kernel_w = kernel_w
        self.kernel_h = kernel_h
        if mode=="bilinear":
            self.upsample = torch.nn.Upsample(scale_factor=(kernel_h, kernel_w),
                                              mode='bilinear')
        else:
            self.upsample = torch.nn.Upsample(scale_factor=(kernel_h, kernel_w),
                                              mode='nearest')
        self.mode = mode
        self.quantize = quantize
        self.last_layer = last_layer

    def forward(self, x):
        clip_min_pre = 0.
        if isinstance(x, tuple):
            input = x[0]
            bitwidth = x[1]
            clip_min_pre = x[2]
        else:
            input = x

        scale_alpha = 0.
        if self.target_device == "T40" and self.quantize:
            if (clip_min_pre < 0.):
                scale_alpha = -1.0

        if self.mode=="zero":
            scales = torch.Tensor([1, 1, self.kernel_h, self.kernel_w])
            output = upsample.apply(input, scales, scale_alpha, self.mode)
        else:
            output = self.upsample(input)

        if self.last_layer:
            return out

        if isinstance(x, tuple):
            return (output, bitwidth, x[2])
        else:
            return output


class PReLU(nn.Module):
    def __init__(self, in_channels, target_device="Txx"):
        super(PReLU, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        op_attr = '{"op_type":"Prelu","attr":{"kernel":%s}}' % ("alpha")
        self.n_op_start = NOp("prelu_start", op_attr, target_device)
        self.n_op_end = NOp("prelu_end", op_attr, target_device)
        self.prelu = torch.nn.PReLU(in_channels)

    def forward(self, input):
        if isinstance(input, tuple):
            x = input[0]
            bitwidth = input[1]
        else:
            x = input

        if not self.training:
            x = self.n_op_start(x)
        x = self.prelu(x)
        if not self.training:
            x = self.n_op_end(x)

        if isinstance(input, tuple):
            return (x, bitwidth, input[2])
        else:
            return x


class Hsigmoid(nn.Module):
    def __init__(self,
                 in_channels,
                 offset_value=3.0,
                 clip_max_value=6.0,
                 target_device="Txx"):
        super(Hsigmoid, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        self.offset_value = offset_value
        self.clip_max_value = float(clip_max_value)

        op_attr = '{"op_type":"Hsigmoid","attr":{"offset_value":%f}}' % (
            offset_value)
        self.n_op_start = NOp("hsigmoid_start", op_attr, target_device)
        self.n_op_end = NOp("hsigmoid_end", op_attr, target_device)

    def forward(self, input):
        if isinstance(input, tuple):
            logging.error(
                "Hsigmoid can only be used as activation_fn, please check it!")
            exit()

        if not self.training:
            input = self.n_op_start(input)
        out = torch.clamp(input + self.offset_value, 0., self.clip_max_value)
        out = out / self.clip_max_value
        if not self.training:
            out = self.n_op_end(out)

        return out


class Hswish(nn.Module):
    def __init__(self, in_channels, target_device="Txx"):
        super(Hswish, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        self.hsigmoid = Hsigmoid(in_channels,
                                 offset_value=3.0,
                                 clip_max_value=6.0,
                                 target_device=target_device)

        op_attr = '{"op_type":"Hswish"}'
        self.n_op_start = NOp("hswish_start", op_attr, target_device)
        self.n_op_end = NOp("hswish_end", op_attr, target_device)

    def forward(self, x):
        if isinstance(x, tuple):
            input = x[0]
        else:
            input = x

        if not self.training:
            input = self.n_op_start(input)

        out = input * self.hsigmoid(input)

        if not self.training:
            out = self.n_op_end(out)

        if isinstance(x, tuple):
            return out, x[1], x[2]
        else:
            return out


class Shortcut(nn.Module):
    def __init__(self,
                 out_channels,
                 activation_fn=ReLU6(),
                 quantize=False,
                 quantize_last_feature=False,
                 last_layer=False,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 clip_max_value=2.0,
                 target_device="Txx"):
        super(Shortcut, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        clip_max_value = min(clip_max_value, 2.0)
        self.flag = False
        if quantize:
            if not last_layer:
                self.flag = True
            elif quantize_last_feature:
                self.flag = True
        self.is_fixpoint = True
        self.QuantizeFeature = QuantizeFeature(out_channels, out_channels,
                                               input_bitwidth=input_bitwidth,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=0.0,
                                               clip_max_value=clip_max_value,
                                               is_fixpoint=self.is_fixpoint,
                                               is_shortcut=True,
                                               target_device=target_device)
        self.sc_input_same_clip = True
        self.last_layer = last_layer
        self.cflag = True
        self.out_channels = out_channels
        self.activation_fn = activation_fn
        if self.flag:
            self.activation_fn = None

    def forward(self, x):
        if isinstance(x[0], tuple) and isinstance(x[1], tuple):
            input = [x[i][0] for i in range(len(x))]
            input_bitwidth = [x[i][1] for i in range(len(x))]
            input_min_value = [x[i][2]>=0 for i in range(len(x))]
            if len(set(input_bitwidth)) != 1:
                logging.error(
                    "Please check your input bit width of Shortcut, all input bit widths should be the same!"
                )
                exit(0)
            if len(set(input_min_value)) != 1:
                self.sc_input_same_clip = False
            self.QuantizeFeature.sc_input_same_clip = self.sc_input_same_clip
            self.QuantizeFeature.input_bitwidth = x[0][1]
            self.QuantizeFeature.output_bitwidth = self.QuantizeFeature.input_bitwidth
            clip_min_pre = min(x[0][2], x[1][2])
            if (clip_min_pre < 0):
                self.QuantizeFeature.clip_min_value = -self.QuantizeFeature.clip_max_value
        else:
            warnings.warn(
                "shortcut: Warning that we didn't find input_bitwidth and input_min_value of the input and I set it to 32 and 0"
            )
            self.QuantizeFeature.input_bitwidth = 32
            clip_min_pre = 0.
            input = x

        if (clip_min_pre < 0.):
            self.img_var = float(2**(x[0][1] - 1) - 1)
        else:
            self.img_var = float(2**(x[0][1]) - 1)

        if (clip_min_pre < 0. and self.cflag):
            self.QuantizeFeature.clip_min_value = -self.QuantizeFeature.clip_max_value
            self.cflag = False
            if (not (torch.min(input[0]) < 0. and torch.min(input[1]) < 0.)):
                warnings.warn(
                    "Please make sure that both inputs of Shortcut contain negative half axis!"
                )
        out = input[0] + input[1]
        if self.flag:
            self.one_tensor = torch.ones(self.out_channels).to(input[0].device)
            self.zero_tensor = torch.zeros(self.out_channels).to(
                input[0].device)
            out = self.QuantizeFeature([
                out, self.one_tensor, self.zero_tensor, clip_min_pre,
                self.img_var
            ])
        else:
            if self.activation_fn != None:
                out = self.activation_fn(out)

        if self.last_layer:
            if not self.training:
                global index
                op_attr = '{"op_type":"output","attr":"index_%d"}' % (index)
                index = index + 1
                self.n_op_out = NOp(op_target="output",
                                    op_attr=op_attr,
                                    target_device=self.target_device)
                out = self.n_op_out(out)
            return out

        if isinstance(x[0], tuple):
            return (out, self.QuantizeFeature.output_bitwidth,
                    self.QuantizeFeature.clip_min_value)
        else:
            return out


class Mul(nn.Module):
    def __init__(self,
                 out_channels,
                 quantize=False,
                 quantize_last_feature=False,
                 last_layer=False,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 target_device="Txx"):
        super(Mul, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        self.flag = False
        if quantize:
            if not last_layer:
                self.flag = True
            elif quantize_last_feature:
                self.flag = True

        self.QuantizeFeature = QuantizeFeature(out_channels, out_channels,
                                               input_bitwidth=input_bitwidth,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=0.0,
                                               clip_max_value=1.0,
                                               target_device=target_device)

        self.last_layer = last_layer
        self.cflag = True
        self.out_channels = out_channels

    def forward(self, x):
        if isinstance(x[0], tuple) and isinstance(x[1], tuple):
            input = [x[i][0] for i in range(len(x))]
            input_bitwidth = [x[i][1] for i in range(len(x))]
            input_min_value = [x[i][2] for i in range(len(x))]
            self.QuantizeFeature.input_bitwidth = max(input_bitwidth)
            self.QuantizeFeature.output_bitwidth = self.QuantizeFeature.input_bitwidth
            clip_min_pre = min(input_min_value)
            if (clip_min_pre < 0.):
                self.QuantizeFeature.clip_min_value = -1.0
        else:
            warnings.warn(
                "Mul: Warning that we didn't find input_bitwidth and input_min_value of the input and I set it to 32 and 0"
            )
            self.QuantizeFeature.input_bitwidth = 32
            clip_min_pre = 0.
            input = x

        if (clip_min_pre < 0.):
            self.img_var = float(2**(x[0][1] - 1) - 1)
        else:
            self.img_var = float(2**(x[0][1]) - 1)

        out = input[0] * input[1]
        if self.flag:
            self.one_tensor = torch.ones(self.out_channels).to(input[0].device)
            self.zero_tensor = torch.zeros(self.out_channels).to(
                input[0].device)
            out = self.QuantizeFeature([
                out, self.one_tensor, self.zero_tensor, clip_min_pre,
                self.img_var
            ])
        if self.last_layer:
            if not self.training:
                global index
                op_attr = '{"op_type":"output","attr":"index_%d"}' % (index)
                index = index + 1
                self.n_op_out = NOp(op_target="output",
                                    op_attr=op_attr,
                                    target_device=self.target_device)
                out = self.n_op_out(out)
            return out

        if isinstance(x[0], tuple):
            return (out, self.QuantizeFeature.output_bitwidth,
                    self.QuantizeFeature.clip_min_value)
        else:
            return out


class Se_Block(nn.Module):
    def __init__(self,
                 in_channels,
                 rate,
                 quantize=False,
                 quantize_last_feature=False,
                 last_layer=False,
                 enable_bias=True,
                 enable_batch_norm=False,
                 weight_bitwidth=32,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 weight_factor=3.0,
                 clip_max_value=6.0,
                 data_format="NCHW",
                 target_device="Txx"):
        super(Se_Block, self).__init__()
        assert data_format == "NCHW"
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]

        self.adaptivepool = AdaptiveAvgpool2D(in_channels, True, quantize,
                                              input_bitwidth, output_bitwidth,
                                              target_device=target_device)
        activation_fn = ReLU6()
        self.quantize = quantize
        if quantize:
            activation_fn = None

        self.flag = False
        if quantize:
            if not last_layer:
                self.flag = True
            elif quantize_last_feature:
                self.flag = True

        self.last_layer = last_layer
        self.conv1 = Conv2D(in_channels,
                            in_channels // rate,
                            stride=1,
                            kernel_h=1,
                            kernel_w=1,
                            activation_fn=activation_fn,
                            enable_bias=enable_bias,
                            enable_batch_norm=enable_batch_norm,
                            quantize=quantize,
                            quantize_last_feature=quantize_last_feature,
                            last_layer=last_layer,
                            weight_bitwidth=weight_bitwidth,
                            input_bitwidth=input_bitwidth,
                            output_bitwidth=output_bitwidth,
                            clip_max_value=clip_max_value,
                            weight_factor=weight_factor,
                            target_device=target_device)
        self.hsigmoid = Hsigmoid(in_channels,
                                 offset_value=3.0,
                                 clip_max_value=6.0,
                                 target_device=target_device)
        self.conv2 = Conv2D(in_channels // rate,
                            in_channels,
                            stride=1,
                            kernel_h=1,
                            kernel_w=1,
                            activation_fn=self.hsigmoid,
                            enable_bias=enable_bias,
                            enable_batch_norm=enable_batch_norm,
                            quantize=quantize,
                            quantize_last_feature=quantize_last_feature,
                            last_layer=last_layer,
                            weight_bitwidth=weight_bitwidth,
                            input_bitwidth=input_bitwidth,
                            output_bitwidth=output_bitwidth,
                            clip_max_value=6.0,
                            weight_factor=weight_factor,
                            target_device=target_device)
        self.QuantizeFeature = QuantizeFeature(in_channels, in_channels,
                                               input_bitwidth=input_bitwidth,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=0.0,
                                               clip_max_value=1.0,
                                               target_device=target_device)
        self.cflag = True
        self.in_channels = in_channels

    def forward(self, x):
        if isinstance(x, tuple):
            input = x[0]
            self.QuantizeFeature.input_bitwidth = x[1]
            clip_min_pre = x[2]
        else:
            input = x
        if (clip_min_pre < 0.):
            self.img_var = float(2**(x[1] - 1) - 1)
        else:
            self.img_var = float(2**(x[1]) - 1)
        if (torch.min(input) < 0. and self.cflag):
            self.QuantizeFeature.clip_min_value = -1.0
            self.cflag = False
        out = self.adaptivepool(x)
        out = self.conv1(out)
        out = self.conv2(out)

        out = input * out[0]
        if self.flag:
            alpha = torch.ones(self.in_channels, device=input.device)
            beta = torch.zeros(self.in_channels, device=input.device)
            out = self.QuantizeFeature(
                [out, alpha, beta, clip_min_pre, self.img_var])

        if self.last_layer:
            if not self.training:
                global index
                op_attr = '{"op_type":"output","attr":"index_%d"}' % (index)
                index = index + 1
                self.n_op_out = NOp(op_target="output",
                                    op_attr=op_attr,
                                    target_device=self.target_device)
                out = self.n_op_out(out)
            return out
        else:
            return (out, self.QuantizeFeature.output_bitwidth, self.QuantizeFeature.clip_min_value)


class Channel_Split(nn.Module):
    def __init__(self, split, target_device="Txx"):
        super(Channel_Split, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2"]
        self.split = split

        if not isinstance(split, list):
            logging.error("The input parameter must be a list!")
            exit()

    def forward(self, input):
        if isinstance(input, tuple):
            x = input[0]
            bitwidth = input[1]
        else:
            x = input

        out = torch.split(x, self.split, dim=1)
        if isinstance(input, tuple):
            out = [(l, bitwidth, input[2]) for l in out]

        return out


class Pixel_Shuffle(nn.Module):
    def __init__(self, upscale_factor, target_device="T40"):
        super(Pixel_Shuffle, self).__init__()
        assert target_device in ["T40"]
        self.upscale_factor = upscale_factor
        self.shuffle = nn.PixelShuffle(upscale_factor)

        op_attr = '{"op_type":"PixelShuffle","attr":{"groups":%d}}' % (
            upscale_factor)
        self.n_op_start = NOp("pixel_shuffle_start", op_attr, target_device)
        self.n_op_end = NOp("pixel_shuffle_end", op_attr, target_device)

    def forward(self, input):
        if isinstance(input, tuple):
            x = input[0]
            bitwidth = input[1]
        else:
            x = input

        if not self.training:
            x = self.n_op_start(x)
        out_channels = int(x.shape[1] /
                           (self.upscale_factor * self.upscale_factor))
        if (out_channels % 32 != 0):
            logging.error(
                "The output channels of PixelShuffle must be divisible by 32, but now it is %d, please check that!"
                % (out_channels))
            exit()
        x = self.shuffle(x)
        if not self.training:
            x = self.n_op_end(x)

        if isinstance(input, tuple):
            return (x, bitwidth, input[2])
        else:
            return x


def LSTM(input_size,
         hidden_size,
         num_layers=1,
         bias=True,
         bidirectional=False,
         initial_state_fw=None,
         initial_state_bw=None,
         return_output_states=False,
         batch_first=True,
         use_squeeze=False,
         quantize=False,
         input_bitwidth=32,
         weight_bitwidth=32,
         output_bitwidth=32,
         weight_factor=3.0,
         target_device="Txx"):
    assert target_device in ["T02", "Txx", "Xs1", "Xs2", "T40"]
    return LSTM_(input_size, hidden_size, num_layers, bias, bidirectional,
                 initial_state_fw, initial_state_bw, return_output_states,
                 batch_first, use_squeeze, quantize, input_bitwidth,
                 weight_bitwidth, output_bitwidth, weight_factor,
                 target_device)


class Embedding(nn.Module):
    def __init__(self,
                 num_embeddings,
                 embedding_dim,
                 padding_idx=None,
                 first_layer=False,
                 quantize=False,
                 input_bitwidth=32,
                 output_bitwidth=32,
                 multi_inputs=True,
                 target_device="Txx",
                 pre_lstm_layer=False):
        super(Embedding, self).__init__()
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        assert isinstance(multi_inputs, bool),"multi_inputs should be a bool value"
        self.input_dim = num_embeddings
        self.output_dim = embedding_dim
        self.quantize = quantize
        self.first_layer = first_layer
        self.output_bitwidth = output_bitwidth
        self.multi_inputs = multi_inputs
        self.target_device = target_device
        self.QuantizeFeature = QuantizeFeature(num_embeddings, num_embeddings,
                                               input_bitwidth=32,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=0.0,
                                               clip_max_value=6.0,
                                               pre_lstm_layer=pre_lstm_layer,
                                               target_device=target_device)
        if self.multi_inputs:
            self.QuantizeFeature1 = QuantizeFeature(num_embeddings, num_embeddings,
                                               input_bitwidth=32,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=0.0,
                                               clip_max_value=6.0,
                                               pre_lstm_layer=pre_lstm_layer,
                                               target_device=target_device)
        self.embedding = nn.Embedding(num_embeddings, embedding_dim,
                                      padding_idx)

    def forward(self, input):
        if not self.training:
            if self.first_layer:
                input = NOp(op_target="input",
                            target_device=self.target_device)(input)
            op_attr = '{"op_type":"Embedding","attr":{"input_dim":%d,"output_dim":%d,"weight_bitwidth":%d,"multi_inputs":%d}}' % \
                        (self.input_dim, self.output_dim, self.output_bitwidth, self.multi_inputs)
            input = NOp(op_target="embedding_start",
                        op_attr=op_attr,
                        target_device=self.target_device)(input)

        if self.multi_inputs:
            x = torch.split(input, input.size()[1] // 2, dim=1)
            x1 = self.embedding(x[0])
            if self.quantize:
                self.one_tensor = torch.ones(self.output_dim).to(input.device)
                self.zero_tensor = torch.zeros(self.output_dim).to(input.device)
                x1 = self.QuantizeFeature(
                    [x1, self.one_tensor, self.zero_tensor, 0., 255.])

            x2 = self.embedding(x[1])
            if self.quantize:
                self.one_tensor = torch.ones(self.output_dim).to(input.device)
                self.zero_tensor = torch.zeros(self.output_dim).to(input.device)
                x2 = self.QuantizeFeature1(
                    [x2, self.one_tensor, self.zero_tensor, 0., 255.])

            x = torch.cat([x1, x2], 2)
        else:
            x = self.embedding(input)
            if self.quantize:
                self.one_tensor = torch.ones(self.output_dim).to(input.device)
                self.zero_tensor = torch.zeros(self.output_dim).to(input.device)
                x = self.QuantizeFeature(
                    [x, self.one_tensor, self.zero_tensor, 0., 255.])

        if not self.training:
            x = NOp(op_target="embedding_end",
                    op_attr=op_attr,
                    target_device=self.target_device)(x)
        return x


class Focus(nn.Module):
    def __init__(self, target_device="Txx"):
        super(Focus, self).__init__()
        '''only supported in conv and it's first layer'''
        assert target_device in ["Txx", "Xs1", "Xs2", "T40"]
        self.route = Route(target_device)

    def forward(self, x):
        x = self.route([
            x[..., ::2, ::2], x[..., 1::2, ::2], x[..., ::2, 1::2],
            x[..., 1::2, 1::2]
        ])
        return x


class SoftAttention(nn.Module):
    def __init__(self,
                 input_size,
                 hidden_size,
                 quantize=False,
                 output_bitwidth=32,
                 clip_max_value=6.0,
                 target_device="T40"):
        super(SoftAttention, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.Tanh(),
        )
        self.linear = nn.Linear(hidden_size, 1, bias=False)

        self.input_size = input_size
        self.hidden_size = hidden_size
        self.quantize = quantize
        self.target_device = target_device
        self.QuantizeFeature = QuantizeFeature(input_size, input_size,
                                               input_bitwidth=32,
                                               output_bitwidth=output_bitwidth,
                                               clip_min_value=-clip_max_value,
                                               clip_max_value=clip_max_value,
                                               is_fixpoint=False,
                                               target_device=target_device)

    def forward(self, x):
        clip_min_pre = 0.
        if isinstance(x, tuple):
            input = x[0]
        else:
            input = x
        if not self.training:
            op_attr = '{"op_type":"SoftAttention","attr":{"input_size":%d,"hidden_size":%d}}' % \
                        (self.input_size, self.hidden_size)
            input = NOp(op_target="softattention_start",
                        op_attr=op_attr,
                        target_device=self.target_device)(input)

        outputs = self.linear(self.fc(input))
        alpha = torch.softmax(outputs, dim=1)
        out = (input * alpha).sum(dim=1)

        if self.quantize:
            out = self.QuantizeFeature(out)

        if not self.training:
            out = NOp(op_target="softattention_end",
                    op_attr=op_attr,
                    target_device=self.target_device)(out)
        return (out, self.QuantizeFeature.output_bitwidth, self.QuantizeFeature.clip_min_value)

